//src/services/userService.ts

import prisma from '@config/db';

export const createUser = async (data: any) => {
  return prisma.user.create({ data });
};

export const getAllUsers = async () => {
  return prisma.user.findMany();
};

export const getUserById = async (userId: number) => {
  return prisma.user.findUnique({
    where: { id: userId },
  });
};

export const updateUser = async (
  userId: number,
  data: {
    firstName?: string;
    lastName?: string;
    age?: number;
    email?: string;
  }
) => {
  return prisma.user.update({
    where: { id: userId },
    data,
  });
};

export const deleteUser = async (userId: number) => {
  return prisma.user.delete({
    where: { id: userId },
  });
};

export const getUserEmail = (email: string) => {
  return prisma.user.findUnique({
    where: {
      email: email,
    },
  });
};
