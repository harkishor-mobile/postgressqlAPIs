import { updateUserAddressById } from '@services/addressService';
import { errorResponse, successResponse } from '@utils/response';
import StatusCode from '@utils/statusCode';
import { Request, Response } from 'express';

export const getUserAddressByIdController = async (
  req: Request,
  res: Response
) => {
  try {
    const id = Number(req.params.id);

    const address = await updateUserAddressById(id);

    if (!address) {
      return res.status(StatusCode.NOT_FOUND).json(
        errorResponse({
          message: 'Address not found',
          statusCode: StatusCode.NOT_FOUND,
          data: null,
        })
      );
    }

    return res.status(StatusCode.OK).json(
      successResponse({
        data: address,
        message: 'Fetched user address successfully',
        statusCode: StatusCode.OK,
      })
    );
  } catch (err: any) {
    return res.status(StatusCode.INTERNAL_SERVER_ERROR).json(
      errorResponse({
        message: err.message || 'Internal server error',
        statusCode: StatusCode.INTERNAL_SERVER_ERROR,
        data: null,
      })
    );
  }
};
