// src/app.ts
import express from 'express';
import morgan from 'morgan';
import cors from 'cors';

// Routes
import userRoutes from '@routes/userRoutes';
import addressRoutes from '@routes/addressRoutes';

const app = express();

// Middlewares
app.use(express.json());
app.use(morgan('dev'));
app.use(cors());

// Routes
app.use('/user', userRoutes);
app.use('/address', addressRoutes);

// Root route
app.get('/', (_req, res) => {
  res.send('Server is running!');
});

export default app;
