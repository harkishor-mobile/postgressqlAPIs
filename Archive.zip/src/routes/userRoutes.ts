//src/routes/userRoute.ts
import { Router } from 'express';
import { createUserController } from '@controllers/users/createUser';
import { deleteUserController } from '@controllers/users/deleteUser';
import { getUserByIdController } from '@controllers/users/getUserById';
import { getUserListController } from '@controllers/users/getUserList';
import { updateUserController } from '@controllers/users/updateUser';

const router = Router();

router.post('/add', createUserController);
router.get('/list', getUserListController);
router.get('/:id', getUserByIdController); // Get /users/:id
router.put('/:id', updateUserController); // Update /users/:id
router.delete('/:id', deleteUserController); // Delete /users/:id

export default router;
