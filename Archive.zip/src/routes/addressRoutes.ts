import { createAddressController } from '@controllers/addresses/createAddress';
import { getUserAddressByIdController } from '@controllers/addresses/getUserAddressById';
import { getUserWithAddressesController } from '@controllers/addresses/getUserWithAddresses';
import { Router } from 'express';

const router = Router();

router.post('/add', createAddressController);
router.get('/user/:userId', getUserWithAddressesController);
router.get('/:id', getUserAddressByIdController);

export default router;
