// src/controllers/users/createUser.ts
import { Request, Response } from 'express';
import { errorResponse, successResponse } from '@utils/response';
import { createUser, getUserEmail } from '@services/userService';
import StatusCode from '@utils/statusCode';

export const createUserController = async (req: Request, res: Response) => {
  try {
    const { firstName, lastName, age, email } = req.body;

    // Check if email already exists
    const duplicateEmail = await getUserEmail(email);
    if (duplicateEmail) {
      return res.status(StatusCode.BAD_REQUEST).json(
        errorResponse({
          message: 'Email already in use',
          statusCode: StatusCode.BAD_REQUEST,
          data: null,
        })
      );
    }

    const user = await createUser({ firstName, lastName, age, email });
    // const user = await createUser(req.body);

    return res.status(StatusCode.OK).json(
      successResponse({
        data: user,
        message: 'User created successfully',
        statusCode: StatusCode.CREATED,
      })
    );
  } catch (err: any) {
    return res.status(StatusCode.INTERNAL_SERVER_ERROR).json(
      errorResponse({
        message: err.message || 'Internal server error',
        statusCode: StatusCode.INTERNAL_SERVER_ERROR,
        data: null,
      })
    );
  }
};

// import { Request, Response } from 'express';
// import { errorResponse, successResponse } from '@utils/response';
// import { createUser } from '@services/userService';
// import StatusCode from '@utils/statusCode';
// import { Prisma } from '@prisma/client';

// export const createUserController = async (req: Request, res: Response) => {
//   try {
//     const { firstName, lastName, age, email } = req.body;
//     const user = await createUser({ firstName, lastName, age, email });

//     return res.status(StatusCode.CREATED).json(
//       successResponse({
//         data: user,
//         message: 'User created successfully',
//         statusCode: StatusCode.CREATED,
//       })
//     );
//   } catch (err: any) {
//     // Handle Prisma unique constraint error
//     if (err instanceof Prisma.PrismaClientKnownRequestError) {
//       if (err.code === 'P2002') {
//         return res.status(StatusCode.BAD_REQUEST).json(
//           errorResponse({
//             message: 'Email already in use',
//             statusCode: StatusCode.BAD_REQUEST,
//             data: null,
//           })
//         );
//       }
//     }

//     return res.status(StatusCode.INTERNAL_SERVER_ERROR).json(
//       errorResponse({
//         message: err.message || 'Internal server error',
//         statusCode: StatusCode.INTERNAL_SERVER_ERROR,
//         data: null,
//       })
//     );
//   }
// };
