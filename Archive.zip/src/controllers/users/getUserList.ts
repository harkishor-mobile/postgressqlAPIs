// src/controllers/users/getUserList.ts
import { getAllUsers } from '@services/userService';
import { errorResponse, successResponse } from '@utils/response';
import StatusCode from '@utils/statusCode';
import { Request, Response } from 'express';

export const getUserListController = async (_: Request, res: Response) => {
  try {
    const users = await getAllUsers();

    // Normalize null values
    const normalizedUsers = users.map((user) => ({
      ...user,
      firstName: user.firstName || '',
      lastName: user.lastName || '',
      age: user.age ?? 0, // or age: user.age ?? 0
      updatedAt: user.updatedAt ? user.updatedAt : '', // optional
    }));
    // Send consistent JSON response
    return res.status(StatusCode.OK).json(
      successResponse({
        // data: users,
        data: normalizedUsers,
        message: 'Users fetched successfully',
        statusCode: StatusCode.OK,
      })
    );
  } catch (err: any) {
    return res.status(StatusCode.INTERNAL_SERVER_ERROR).json(
      errorResponse({
        message: err.message || 'Internal server error',
        statusCode: StatusCode.INTERNAL_SERVER_ERROR,
        data: null,
      })
    );
  }
};
