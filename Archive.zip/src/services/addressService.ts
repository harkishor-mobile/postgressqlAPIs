import prisma from '@config/db';
export const createAddress = async (data: {
  userId: number;
  street: string;
  city: string;
  state: string;
  zipCode?: string;
}) => {
  return prisma.address.create({ data });
};

export const getUserAddressList = async (userId: number) => {
  return prisma.user.findUnique({
    where: { id: userId },
    include: { addresses: true }, // Include all related addresses
  });
};

export const updateUserAddressById = async (addressId: number) => {
  return prisma.address.findUnique({
    where: {
      id: addressId,
    },
  });
};
